# Change Log

All notable changes to the "flutter-redux-gen" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [1.0.1]

- How to Use Gifs added.

## [1.0.0]

- Create Redux Set (Folder with action, middleware, reducer and state)

## [0.0.4]

- Create Middleware
- Create Action

## [0.0.3]

- Create Reducer

## [0.0.2]

- Create State bugs fixed
- State name can't name any special chanracter other than "_"
- State creation loading and error variable added defaultly.
- State Name bug fixed.

## [0.0.1]

- Initial release